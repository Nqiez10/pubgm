## Pubg Mobile Player Entity Offsets

![Pubg Mobile Player Entity Offsets](https://raw.githubusercontent.com/atiksoftware/pubg_mobile_memory_hacking_examples/master/Offsets/images/ReClassPlayer.png "Pubg Mobile Player Entity Offsets")
 