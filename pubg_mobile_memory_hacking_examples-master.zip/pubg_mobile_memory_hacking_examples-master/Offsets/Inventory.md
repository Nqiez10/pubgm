## Pubg Mobile Inventory Entity Offsets

![Pubg Mobile Inventory Entity Offsets](https://raw.githubusercontent.com/atiksoftware/pubg_mobile_memory_hacking_examples/master/Offsets/images/ReClassInventory.png "Pubg Mobile Inventory Entity Offsets")
 