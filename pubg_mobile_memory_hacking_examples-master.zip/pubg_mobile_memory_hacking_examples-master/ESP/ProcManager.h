#pragma once
#include "pch.h"


class ProcManager{
public:
	ProcManager();
	~ProcManager();
	static int getAowProcID();
};

