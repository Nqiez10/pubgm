# Pubg Mobile Gameloop ESP Source
[![GitHub](https://img.shields.io/badge/Author-Amiral%20Router-blue)]()
[![Hits](https://hits.seeyoufarm.com/api/count/incr/badge.svg?url=https%3A%2F%2Fgithub.com%2Fatiksoftware%2Fpubg_mobile_memory_hacking_examples)]()
[![GitHub stars](https://img.shields.io/github/stars/atiksoftware/pubg_mobile_memory_hacking_examples?color=brightgreen)]()

Discord 
[https://discord.gg/r29z6XW](https://discord.gg/r29z6XW)

Hello guy. Well come to my video tutorial.  
In this tutorial i will make simple esp for pubg mobile gameloop  
I will not show how how can you by pass anti cheat system. just will show how can you make esp and read virtual memory with C++  
And i will show how can you create overlay, and other what you need for esp. but i will not use directx or opengl native. I will use sfml library on c++

Its my first video tutorial on youtube. İts little hard for me. Also i have not english language. Forgive me if I have a mistake while talking. Then i will move step by step videos. 

Whats my steps.  
1 Create Project  
3 Create overlay on game screen for draw some things.  
2 Create process manager for find android emulater process id  
4 Memory manager: I will use driver for read momory. In this tutorial i will use kpreccess driver with bypaph  
5 Create esp for scan game entity list and other entity details.  
6 Create entity object  
7 ini file reader for settings and enetity informations.

But i will not do code about aim hacking. Esp only.   
I will use VStudio 2017. Because i will use SFML libray for draw esp. And SFML library support VStudio 2017.  


**[#1 - How Can I Find Pubg Mobile View Matrix Pattern](https://www.youtube.com/watch?v=ya0rbAwFKdY)**
[![#1 - How Can I Find Pubg Mobile View Matrix Pattern](https://i3.ytimg.com/vi/ya0rbAwFKdY/maxresdefault.jpg)](https://www.youtube.com/watch?v=ya0rbAwFKdY)

**[#2 - Create a New C++ Console Application | Pubg Mobile Hacking Tutorial](https://www.youtube.com/watch?v=8DxZExFLges)**
[![#2 - Create a New C++ Console Application | Pubg Mobile Hacking Tutorial](https://i3.ytimg.com/vi/8DxZExFLges/maxresdefault.jpg)](https://www.youtube.com/watch?v=8DxZExFLges)

**[#3 - Create a Overlay Window - Import SFML Library | Pubg Mobile Hacking Tutorial](https://www.youtube.com/watch?v=mukNNm5MxJE)**
[![#3 - Create a Overlay Window - Import SFML Library | Pubg Mobile Hacking Tutorial](https://i3.ytimg.com/vi/mukNNm5MxJE/maxresdefault.jpg)](https://www.youtube.com/watch?v=mukNNm5MxJE)

**[#4 - Process Manager - Find Aow Process ID | Pubg Mobile Hacking Tutorial](https://www.youtube.com/watch?v=nVuDz1hbYEs)**
[![#4 - Process Manager - Find Aow Process ID | Pubg Mobile Hacking Tutorial](https://i3.ytimg.com/vi/nVuDz1hbYEs/maxresdefault.jpg)](https://www.youtube.com/watch?v=nVuDz1hbYEs)

**[#5 - How Can I Change Driver Name - kprocesshacker.sys | Pubg Mobile Hacking Tutorial](https://www.youtube.com/watch?v=uJiurAlhsWw)**
[![#5 - How Can I Change Driver Name - kprocesshacker.sys | Pubg Mobile Hacking Tutorial](https://i3.ytimg.com/vi/uJiurAlhsWw/maxresdefault.jpg)](https://www.youtube.com/watch?v=uJiurAlhsWw)

**[#6 - Colorful Terminal Output | Pubg Mobile Hacking Tutorial](https://www.youtube.com/watch?v=UI6xyrmGtQ4)**
[![#6 - Colorful Terminal Output | Pubg Mobile Hacking Tutorial](https://i3.ytimg.com/vi/UI6xyrmGtQ4/maxresdefault.jpg)](https://www.youtube.com/watch?v=UI6xyrmGtQ4)

**[#7 - Memory Manager - Connect to Driver | Pubg Mobile Hacking Tutorial](https://www.youtube.com/watch?v=V3bd7XEfW68)**
[![#7 - Memory Manager - Connect to Driver | Pubg Mobile Hacking Tutorial](https://i3.ytimg.com/vi/V3bd7XEfW68/maxresdefault.jpg)](https://www.youtube.com/watch?v=V3bd7XEfW68)

**[#8 - ESP - Find Base Points | Pubg Mobile Hacking Tutorial](https://www.youtube.com/watch?v=TpCXqkRH08A)**
[![#8 - ESP - Find Base Points | Pubg Mobile Hacking Tutorial](https://i3.ytimg.com/vi/TpCXqkRH08A/maxresdefault.jpg)](https://www.youtube.com/watch?v=TpCXqkRH08A)